#include "mymacros.h"

int main(int argc, char** argv) {

    char *args[MAXARGS + 1];

	printf("Bem-vinda/o ao i-banco-terminal\n\n");

    int file_in = open("/tmp/i-banco-pipe", O_WRONLY, 0666);
    
    if(file_in < 0) {
    	printf("ERRO AO CRIAR/ABRIR O i-banco-pipe\n");
    	exit(-1);
    }

    unlink("/tmp/i-banco-terminal");

    if(mkfifo("/tmp/i-banco-terminal", 0666) < 0) {
    	printf("ERRO NA CRIACAO DO PIPE\n");
    	exit(-1);
    }

    int file_out = open("/tmp/i-banco-terminal", O_RDONLY);

    if(file_out < 0) {
    	printf("ERRO AO CRIAR/ABRIR O i-banco-terminal\n");
    	exit(-1);
    }

    comando_t comando;

    char buffer[BUFFER_SIZE];

    while (1) {
        int numargs;
    
        numargs = readLineArguments(args, MAXARGS+1, buffer, BUFFER_SIZE);

        char text[MAXIMUM_STR_SIZE];

        /* EOF (end of file) do stdin ou comando "sair" */
        if (numargs < 0 || (numargs > 0 && (strcmp(args[0], COMANDO_SAIR) == 0))) {

            comando.operacao = OP_SAIR;

        	/* Comando Sair */
            if (numargs < 2) {
            	comando.valor = SAIR_NORMAL;
            }

            /* Comando Sair Agora */
            else {
                comando.valor = SAIR_AGORA;
            }

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }

            if(close(file_in) < 0) {
            	printf("ERRO AO FECHAR O PIPE\n");
            	exit(-1);
            }
        }
    
        else if (numargs == 0)
            /* Nenhum argumento; ignora e volta a pedir */
            continue;

        /* Debitar */
        else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {
            comando.operacao = OP_DEBITAR;
            comando.idConta = atoi(args[1]);
            comando.valor = atoi(args[2]);

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }

            if(read(file_out, text, sizeof(text)) < 0) {
				printf("ERRO NA LEITURA DO i-banco-terminal");
				exit(-1);            	
            }

        	printf("%s", text);
        }

        /* Creditar */
        else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {
            comando.operacao = OP_CREDITAR;
            comando.idConta = atoi(args[1]);
            comando.valor = atoi(args[2]);

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }

            if(read(file_out, text, sizeof(text)) < 0) {
				printf("ERRO NA LEITURA DO i-banco-terminal");
				exit(-1);            	
            }

        	printf("%s", text);
        }

        /* Ler Saldo */
        else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {
            comando.operacao = OP_LERSALDO;
            comando.idConta = atoi(args[1]);

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }

            if(read(file_out, text, sizeof(text)) < 0) {
				printf("ERRO NA LEITURA DO i-banco-terminal");
				exit(-1);            	
            }

        	printf("%s", text);
        }

        /* Transferir */
        else if(strcmp(args[0], COMANDO_TRANSFERIR) == 0) {
            comando.operacao = OP_TRANSFERIR;
            comando.idConta = atoi(args[1]);
            comando.idContaDestino = atoi(args[2]);
            comando.valor = atoi(args[3]);

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }
        }

        /* Simular */
        else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {
        	comando.operacao = OP_SIMULAR;
            comando.valor = atoi(args[1]);

            if(write(file_in, &comando, sizeof(comando)) < 0) {
            	printf("ERRO NO ENVIO DO COMANDO\n");
            	exit(-1);
            }

            if(read(file_out, text, sizeof(text)) < 0) {
				printf("ERRO NA LEITURA DO i-banco-terminal");
				exit(-1);            	
            }

        	printf("%s", text);
        }

        else {
            printf("Comando desconhecido. Tente de novo.\n\n");
        }
    }
    return 0;
}