/*
 * 
 *               I-BANCO
 * 
 *  Projeto SO - Exercicio 4, version 1
 *  Sistemas Operativos, DEI/IST/ULisboa 2016-17
 *  
 *  Co-autores: Tomas Carrasco nº 84774
 *              Miguel Viegas nº 84747
 *
 */

#include "mymacros.h"

int main () {

    int pid_list[MAXPROSS]/*, status*/;

    inicializarContas();
    init_vec_0(pid_list,MAXPROSS);

    cria_pool();
    init_sem();
    init_trincos(NUM_CONTAS);
    init_log();

    printf("Bem-vinda/o ao i-banco\n\n");

    unlink("/tmp/i-banco-pipe");

	if(mkfifo("/tmp/i-banco-pipe", 0666) < 0) {
		printf("ERRO NA CRIACAO DO PIPE\n");
		exit(-1);
	}

    int file_in = open("/tmp/i-banco-pipe", O_RDONLY);
    
    if(file_in < 0) {
    	printf("ERRO AO CRIAR/ABRIR i-banco-pipe\n");
    	exit(-1);
    }

	int file_out = open("/tmp/i-banco-terminal", O_WRONLY);

    if(file_out < 0) {
   		printf("ERRO AO CRIAR/ABRIR O i-banco-terminal\n");
   		exit(-1);
   	}

    comando_t comando;
    char text[MAXIMUM_STR_SIZE];
      
    while (1) {

    	if(read(file_in, &comando, sizeof(comando)) < 0) {
    		printf("ERRO AO LER i-banco-pipe\n");
    		exit(-1);
    	}

        /* EOF (end of file) do stdin ou comando "sair"  TRATAR DESTA MERDA NO FIM
        if (comando.operacao == OP_SAIR) {
            if (numargs <= 2) {     Comando Sair 
                int i, pid_wait, tid_join;

                for(i = 0; i < NUM_TRABALHADORAS; i++)  Envio da operacao sair 
                    produz(OP_SAIR, ATRIBUTO_NULL, ATRIBUTO_NULL, ATRIBUTO_NULL);

                for(i = 0; i < NUM_TRABALHADORAS; i++) {  Terminio das tarefas trabalhadoras 
                    tid_join = pthread_join(tid[i], NULL);
                    if(tid_join == 0)
                        printf("TAREFA TERMINADA COM SUCESSO (TID=%ld)\n", tid[i]);
                    else
                        printf("ERRO: TAREFA TERMINADA ABRUPTAMENTE\n");

                }

                destroy();

                if(close(file) < 0) {
                	printf("log.txt NAO FOI FECHADO CORRETAMENTE\n\n");
                	exit(1);
                }

                printf("i-banco vai terminar.\n--\n");
                for(i = 0; i < MAXPROSS; i++)
                    if(pid_list[i] != 0) {
                       if(numargs > 1 && strcmp(args[1], COMANDO_SAIR_AGORA) == 0) {  excepcao do sair agora 
                            kill(pid_list[i], SIGUSR1);
                        }
                        pid_wait = waitpid(pid_list[i], &status, 0);
                        printf("FILHO TERMINADO (PID=%d; terminou %s)\n", pid_wait, (WIFEXITED(status)) ? "normalmente" : "abruptamente");
                    }
                printf("--\ni-banco terminou.\n");
            }

            else {
                printf("%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_SAIR);
            }            
            
            exit(EXIT_SUCCESS);
        }*/

        /* Debitar */
        else if (comando.operacao == OP_DEBITAR) {

            if (comando.valor < 0) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_DEBITAR);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
	           	continue;
            }

            if (!contaExiste(comando.idConta)) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s(%d): Conta não existe.\n\n", COMANDO_DEBITAR, comando.idConta);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            produz(comando);
        }

        /* Creditar */
        else if (comando.operacao == OP_CREDITAR) {

            if (comando.valor < 0) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_CREDITAR);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }                
                continue;
            }

            if (!contaExiste(comando.idConta)) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s(%d): Conta não existe.\n\n", COMANDO_CREDITAR, comando.idConta);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            produz(comando);
        }

        /* Ler Saldo */
        else if (comando.operacao == OP_LERSALDO) {

            if (!contaExiste(comando.idConta)) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s(%d): Conta não existe.\n\n", COMANDO_LER_SALDO, comando.idConta);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            produz(comando);
        }

        /* Transferir */
        else if(comando.operacao == OP_TRANSFERIR) {

            if(comando.valor < 0) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_TRANSFERIR);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            if (!contaExiste(comando.idConta) || !contaExiste(comando.idContaDestino)) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s(%d, %d): Conta não existe.\n\n", COMANDO_DEBITAR, comando.idConta, comando.idContaDestino);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }                
                continue;
            }

            if(comando.idConta == comando.idContaDestino) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s(%d, %d): id das contas inválidas.\n\n", COMANDO_TRANSFERIR, comando.idConta, comando.idContaDestino);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            produz(comando);
        }

        /* Simular */
        else if (comando.operacao == OP_SIMULAR) {
            int pid;

            if (comando.valor < 0) {
                snprintf(text, MAXIMUM_STR_SIZE, "%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_SIMULAR);
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            if(list_full(pid_list, MAXPROSS) == TRUE) {
                snprintf(text, MAXIMUM_STR_SIZE, "Erro: Demasiados processos.\n\n");
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            pthread_mutex_lock(&trinco_simular);
            while(obtem_valor_contador() > 0){
                pthread_cond_wait(&pode_simular, &trinco_simular);
            }
            pthread_mutex_unlock(&trinco_simular);

            pid = fork();

            if(pid < 0) {
                snprintf(text, MAXIMUM_STR_SIZE, "Erro: Processo não criado.\n\n");
                if(write(file_out, text, sizeof(text)) < 0) {
                	printf("ERRO AO ENVIAR OUTPUT\n");
                	exit(-1);
                }
                continue;
            }

            push_pid(pid_list, MAXPROSS, pid);

            if(pid == 0) {  /* Codigo do processo filho. */
                char file_name[MAXIMUM_STR_SIZE];

                snprintf(file_name, MAXIMUM_STR_SIZE, "i-banco-sim-%d.txt", getpid());
                file = open(file_name, O_WRONLY | O_CREAT | O_APPEND | O_TRUNC, 0666);
               
                if(file < 0) {
                	printf("NAO FOI POSSIVEL CRIAR/ABRIR O %s\n", file_name);
                	exit(1);
                }
                dup2(file, STDOUT_FILENO);
                simular(comando.valor);
            }
        }

        else {
            printf("Comando desconhecido. Tente de novo.\n\n");
        }
    }
    return 0;
}