#ifndef FUNCOESAUXILIARES_H
#define FUNCOESAUXILIARES_H

#define COMANDO_DEBITAR "debitar"
#define COMANDO_CREDITAR "creditar"
#define COMANDO_LER_SALDO "lerSaldo"
#define COMANDO_SIMULAR "simular"
#define COMANDO_SAIR "sair"
#define COMANDO_SAIR_AGORA "agora"


#define TRUE 1
#define FALSE 0
#define NUM_TRABALHADORAS 3
#define BUFFERSIZE_T (2*NUM_TRABALHADORAS)
#define OP_LERSALDO 0
#define OP_CREDITAR 1
#define OP_DEBITAR 2
#define OP_SAIR 3

typedef struct Operacao {
	int operacao;
	int idConta;
	int valor;
} comando_t; 

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Recebe: Ponteiro para um vetor de inteiros.           *
 *         O tamanho do vetor (inteiros).                *
 * Retorna: Nada.                                        *
 * Descricao: Todas as entradas sao inicializadas a '0'  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void init_vec_0(int *vec, int size);



/* * * * * * * * * * * * * * * * * * * * * * * *\
 * Recebe: Ponteiro para um vetor de inteiros. *
 *         Tamanho do vetor (inteiro).         *
 *         Um Pid (inteiro)                    *
 * Retorna: Nada.                              *
 * Descricao: Coloca o valor do pid no vetor.  *
 *   '0' nao é valor de nenhum pid.            *
\* * * * * * * * * * * * * * * * * * * * * * * */
void push_pid(int *vec, int size, int pid);



/* * * * * * * * * * * * * * * * * * * * * * * * * *\ 
 * Recebe: Um ponteiro para um vetor de inteiros.  *
 *         O tamanho para um vetor (inteiro).      *
 * Retorna: Inteiro correpondente a valor logico.  *
 * Descricao: Retorna "True" se a lista nao tem    *
 *   entradas a '0', "False" caso contrario.       *
\* * * * * * * * * * * * * * * * * * * * * * * * * */
int list_full(int *vec, int size);

void init_vec_trinco(int n_contas);

void init_sem();

void cria_pool();

void produz(int op, int id, int valor);

void *consome();

void trata_comando(comando_t comando);

#endif
