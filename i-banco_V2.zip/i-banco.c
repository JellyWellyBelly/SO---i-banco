/*
// Projeto SO - exercicio 1, version 1
// Sistemas Operativos, DEI/IST/ULisboa 2016-17
*/

#include "commandlinereader.h"
#include "contas.h"
#include "funcoesaux.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>

#define COMANDO_DEBITAR "debitar"
#define COMANDO_CREDITAR "creditar"
#define COMANDO_LER_SALDO "lerSaldo"
#define COMANDO_SIMULAR "simular"
#define COMANDO_SAIR "sair"
#define COMANDO_SAIR_AGORA "agora"

#define MAXARGS 3
#define MAXPROSS 20
#define BUFFER_SIZE 100
#define ZERO "0"

pthread_t tid[NUM_TRABALHADORAS];
pthread_mutex_t trinco_p, trinco_c;
pthread_mutex_t vec_trinco[NUM_CONTAS];

int main (int argc, char** argv) {

    char *args[MAXARGS + 1];
    char buffer[BUFFER_SIZE];

    int pid_list[MAXPROSS], status;

    inicializarContas();
    init_vec_0(pid_list,MAXPROSS);

    cria_pool();
    init_sem();
    if(pthread_mutex_init(&trinco_p, 0))
        exit(1);
    if(pthread_mutex_init(&trinco_c, 0))
        exit(1);
    init_vec_trinco(NUM_CONTAS);

    printf("Bem-vinda/o ao i-banco\n\n");
      
    while (1) {
        int numargs;
    
        numargs = readLineArguments(args, MAXARGS+1, buffer, BUFFER_SIZE);

        /* EOF (end of file) do stdin ou comando "sair" */
        if (numargs < 0 || (numargs > 0 && (strcmp(args[0], COMANDO_SAIR) == 0))) {
            if (numargs <= 2) {    /* Comando Sair */
                int i, pid_wait, tid_join;

                for(i = 0; i < NUM_TRABALHADORAS; i++)
                    produz(OP_SAIR, -1, -1);

                for(i = 0; i < NUM_TRABALHADORAS; i++) {
                    tid_join = pthread_join(tid[i], NULL);
                    if(tid_join == 0)
                        printf("TAREFA TERMINADA COM SUCESSO (TID=%ld)\n", tid[i]);
                    else
                        printf("ERRO: TAREFA TERMINADA ABRUPTAMENTE\n");

                }

                printf("i-banco vai terminar.\n--\n", args[0]);
                for(i = 0; i < MAXPROSS; i++)
                    if(pid_list[i] != 0) {
                        if(numargs > 1 && strcmp(args[1], COMANDO_SAIR_AGORA) == 0) { /* excepcao do sair agora */
                            kill(pid_list[i], SIGUSR1);
                        }
                        pid_wait = waitpid(pid_list[i], &status, 0);
                        printf("FILHO TERMINADO (PID=%d; terminou %s)\n", pid_wait, (WIFEXITED(status)) ? "normalmente" : "abruptamente");
                    }
                printf("--\ni-banco terminou.\n");
            }

            else {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_SAIR);
            }            
            
            exit(EXIT_SUCCESS);
        }
    
        else if (numargs == 0)
            /* Nenhum argumento; ignora e volta a pedir */
            continue;

        /* Debitar */
        else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {
            int idConta, valor;

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_DEBITAR);
	           continue;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);
            produz(OP_DEBITAR, idConta, valor);
        }

        /* Creditar */
        else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {
            int idConta, valor;

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_CREDITAR);
                continue;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);
            produz(OP_CREDITAR, idConta, valor);
        }

        /* Ler Saldo */
        else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {
            int idConta;

            if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_LER_SALDO);
                continue;            
            }

            idConta = atoi(args[1]);
            produz(OP_LERSALDO, idConta, -1);
        }

        /* Simular */
        else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {
            int numAnos, pid;

            if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_SIMULAR);
                continue;
            }

           if(list_full(pid_list, MAXPROSS) == TRUE) {
                printf("Erro. Demasiados processos\n\n");
                continue;
            }

            numAnos = atoi(args[1]);

            if(numAnos < 0)
                break;

            if(numAnos == 0 && strcmp(args[1],ZERO) != 0)
                break;


            pid = fork();
            
            if(pid < 0) {
                printf("Erro. Processo não criado\n\n");
                continue;
            }

            push_pid(pid_list, MAXPROSS, pid);

            if(pid == 0)  /* Codigo do processo filho. */
                simular(numAnos);
        }

        else {
            printf("Comando desconhecido. Tente de novo.\n");
        }
    }
    return 0;
}